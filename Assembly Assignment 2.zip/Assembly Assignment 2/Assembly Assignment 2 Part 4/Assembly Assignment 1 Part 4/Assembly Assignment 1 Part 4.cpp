// Assembly Assignment 1 Part 4.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

int oneHundred = 100;
int oneTen = 10;
int one = 1;
int providedNUmber = 0;
int sumOfNumber = 0;

int five = 5;
int four = 4;
int answer = 0;
int isItDeleted=0;


int main()
{
	cout << "PLease enter a 3 digit number: ";
	cin >> providedNUmber;


	__asm {
		mov eax, providedNUmber;	//move in number we entered 123
		mov ecx, oneHundred;		//move 100 into divierd reg
		cdq;
		div ecx;					//divide EAX by ECX(100)
		mov ebx, eax;				//copy answer from division into EBX
		mov eax, edx;				//Move remander to EAX for further dividing
		mov ecx, oneTen;				//Move 10 into dividing Reg
		cdq;
		div ecx;					//Divide EAX by ECX(10)
		add ebx, eax;				//add result from Divid to EBX(FINAL TOTAL)
		add ebx, edx;
		mov sumOfNumber, ebx;

		mov eax, five;
		mov ebx, four;
		mul ebx;

		mov answer, eax;
		mov isItDeleted, ebx;


	
	}

	cout << " total: " << sumOfNumber;
	cout << endl << answer << endl << isItDeleted << endl;
	cin >> sumOfNumber;



	 return 0;
}

