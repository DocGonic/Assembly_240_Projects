// Assembly Assignment 1 Part 2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

int a = 0, b = 0, c = 0, h = 0;
int swidth = 0, slength = 0;
int tArea=0, tPerimeter=0, sArea=0, sPerimeter=0;
int nullVal = 0;
int main()
{
	cout << "       /|\        ----------------------------      " << endl;
	cout << "      / | \       |                          |      " << endl;
	cout << "    a/  |  \b     |                          | width" << endl;
	cout << "    /  h|   \     |                          |      " << endl;
	cout << "   /    |    \    |                          |      " << endl;
	cout << "   -----------    ----------------------------      " << endl;
	cout << "        c                      Length               " << endl;
	cout << endl << endl;
	cout << "Enter the values of a,b,c and h for the triangle: ";
	cin >> a >> b >> c >> h;
	cout << endl;
	cout << "Enter the length and the width of the rectangle:  ";
	cin >> slength >> swidth;
	cout << endl;

	__asm {
		mov eax, c;
		mul h;
		mov ecx, 2;
		div ecx;
		mov tArea, eax;

		mov eax, nullVal;
		add eax, a;
		add eax, b;
		add eax, c;
		mov tPerimeter, eax;

		//mov eax, nullVal;
		mov eax, slength;
		mul swidth;
		mov sArea, eax;

		mov eax, slength;
		add eax, slength;
		add eax, swidth;
		add eax, swidth;
		mov sPerimeter, eax;


	}




	cout << "Triangle" << endl;
	cout << "        Area............" << tArea << endl;
	cout << "        Perimeter......." << tPerimeter << endl;
	cout << "Rectangle" << endl;
	cout << "        Area............" << sArea << endl;
	cout << "        Perimeter......." << sPerimeter << endl;


	


	cin >> a;




    return 0;
}

