// ConsoleApplication2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

short drinkVal = 2, sandwichVal = 4, totalVal = 0, numberOfDrinks = 0, numberOfSandwhichs = 0, nullVal=0;
int main()
{
	cout << "--------------------MENU------------------" << endl;
	cout << "Drinks...............................$2" << endl;
	cout << "Sandwiches...........................$4" << endl;
	cout << "How many Drinks? ";
	cin >> numberOfDrinks;
	cout << endl;
	cout << "How many Sandwiches? ";
	cin >> numberOfSandwhichs;
	cout << endl;

	__asm {
		//mov ax, nullVal;
		mov ax, drinkVal;
		mul numberOfDrinks;
		mov totalVal, ax;
		//mov ax, nullVal;
		mov ax, sandwichVal;
		mul numberOfSandwhichs;
		add totalVal, ax;
	}	
	cout << "Your Total Bill is: $" << totalVal << endl;
	cout << "Enter Q to quit: ";
	cin >> totalVal;

    return 0;
}

