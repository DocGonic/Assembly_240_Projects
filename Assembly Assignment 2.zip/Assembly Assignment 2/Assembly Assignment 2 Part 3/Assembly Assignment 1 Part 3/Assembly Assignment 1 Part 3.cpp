// Assembly Assignment 1 Part 3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

short givenTemp = 0, convertedTemp = 0;
short five = 5, nine = 9;
int main()
{
	cout << "Enter Tempature in Fahrenheit: ";
	cin >> givenTemp;

	__asm {
	
		//mov eax, 0;
		//mov ecx, 0;
		mov ax, givenTemp;
		sub ax,32;
		mov cx, five;
		mul cx;
		mov cx, nine;
		div cx;
		mov convertedTemp, ax;
	}

	cout << givenTemp << "F* is " << convertedTemp << " C*" << endl;
	cin >> givenTemp;




    return 0;
}

